import { Outlet } from "react-router-dom"
import { useState } from "react"
import { Home, Pill, Bell, Settings, Menu, X, LogOut, User, ChevronDown, HelpCircle, Shield } from "lucide-react"
import { Link, useLocation } from "react-router-dom"

const DashboardLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const location = useLocation()

  const navigation = [
    {
      name: "Dashboard",
      href: "/app",
      icon: Home,
      description: "Quick summary of today's medications, reminders, and current streaks",
    },
    {
      name: "Medications",
      href: "/app/medications",
      icon: Pill,
      description: "Add, edit, or delete your medicines with dosage and schedule details",
    },
    {
      name: "Reminders",
      href: "/app/reminders",
      icon: Bell,
      description: "Set up when and how you want to be reminded via email or WhatsApp",
    },
    {
      name: "Settings",
      href: "/app/profile",
      icon: Settings,
      description: "Manage your MedTrack account, profile details, and preferences",
    },
  ]

  const isActive = (href) => {
    if (href === "/app") {
      return location.pathname === "/app"
    }
    return location.pathname.startsWith(href)
  }

  const getCurrentPageInfo = () => {
    const currentNav = navigation.find((nav) => isActive(nav.href))
    return currentNav || navigation[0]
  }

  const currentPage = getCurrentPageInfo()

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black bg-opacity-50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-xl transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:flex-shrink-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200 bg-gradient-to-r from-[#F97316] to-[#FB923C] flex-shrink-0">
            <Link to="/" className="flex items-center">
              <img src="/logo.png" alt="MedTrack" className="h-8 w-auto" />
            </Link>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden text-white hover:text-gray-200 transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 mt-4 px-3 overflow-y-auto">
            <ul className="space-y-1">
              {navigation.map((item) => {
                const Icon = item.icon
                const active = isActive(item.href)

                return (
                  <li key={item.name}>
                    <Link
                      to={item.href}
                      className={`group flex flex-col p-3 rounded-lg transition-all duration-200 ${
                        active
                          ? "bg-gradient-to-r from-[#F97316] to-[#FB923C] text-white shadow-md"
                          : "text-gray-700 hover:bg-gray-50 hover:text-[#F97316]"
                      }`}
                      onClick={() => setSidebarOpen(false)}
                    >
                      <div className="flex items-center">
                        <Icon
                          size={18}
                          className={`mr-2 transition-colors ${
                            active ? "text-white" : "text-gray-500 group-hover:text-[#F97316]"
                          }`}
                        />
                        <span className="font-medium text-sm">{item.name}</span>
                      </div>
                      <p className={`text-xs mt-1 ml-5 leading-relaxed ${active ? "text-white/80" : "text-gray-500"}`}>
                        {item.description}
                      </p>
                    </Link>
                  </li>
                )
              })}
            </ul>

            {/* Quick Stats */}
            <div className="mt-6 p-3 bg-gradient-to-br from-[#F97316]/10 to-[#FB923C]/10 rounded-lg border border-[#F97316]/20">
              <h3 className="text-xs font-semibold text-gray-900 mb-2">Today's Progress</h3>
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-600">Medications taken</span>
                  <span className="text-sm font-bold text-[#F97316]">3/4</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-600">Current streak</span>
                  <span className="text-sm font-bold text-green-600">12 days</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
                  <div
                    className="bg-gradient-to-r from-[#F97316] to-[#FB923C] h-1.5 rounded-full transition-all duration-500"
                    style={{ width: "75%" }}
                  ></div>
                </div>
              </div>
            </div>
          </nav>

          {/* User section */}
          <div className="p-3 border-t border-gray-200 bg-white flex-shrink-0">
            <div className="relative">
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="w-full flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50 transition-colors group"
              >
                <div className="w-8 h-8 bg-gradient-to-r from-[#F97316] to-[#FB923C] rounded-full flex items-center justify-center">
                  <User size={16} className="text-white" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-medium text-gray-900">John Doe</p>
                  <p className="text-xs text-gray-500">john@example.com</p>
                </div>
                <ChevronDown
                  size={14}
                  className={`text-gray-400 transition-transform duration-200 ${userMenuOpen ? "rotate-180" : ""}`}
                />
              </button>

              {/* User Dropdown Menu */}
              {userMenuOpen && (
                <div className="absolute bottom-full left-0 right-0 mb-2 bg-white rounded-xl shadow-lg border border-gray-200 py-2">
                  <Link
                    to="/app/profile"
                    className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-[#F97316] transition-colors"
                    onClick={() => {
                      setUserMenuOpen(false)
                      setSidebarOpen(false)
                    }}
                  >
                    <Settings size={16} className="mr-3" />
                    Account Settings
                  </Link>
                  <Link
                    to="/help"
                    className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-[#F97316] transition-colors"
                  >
                    <HelpCircle size={16} className="mr-3" />
                    Help & Support
                  </Link>
                  <Link
                    to="/privacy"
                    className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-[#F97316] transition-colors"
                  >
                    <Shield size={16} className="mr-3" />
                    Privacy Policy
                  </Link>
                  <hr className="my-2 border-gray-200" />
                  <button className="w-full flex items-center px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors">
                    <LogOut size={16} className="mr-3" />
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <div className="bg-white shadow-sm border-b border-gray-200 flex-shrink-0">
          <div className="flex items-center justify-between h-16 px-6">
            <div className="flex items-center">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden text-gray-500 hover:text-gray-700 transition-colors mr-4"
              >
                <Menu size={24} />
              </button>

              <div className="flex items-center space-x-4">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center bg-gradient-to-r from-[#F97316] to-[#FB923C]`}
                >
                  <currentPage.icon size={20} className="text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-semibold text-gray-900">{currentPage.name}</h1>
                  <p className="text-sm text-gray-600 hidden sm:block">{currentPage.description}</p>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              {/* Notifications */}

              {/* Mobile user menu */}
              <div className="lg:hidden relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="w-8 h-8 bg-gradient-to-r from-[#F97316] to-[#FB923C] rounded-full flex items-center justify-center"
                >
                  <User size={16} className="text-white" />
                </button>

                {userMenuOpen && (
                  <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-lg border border-gray-200 py-2">
                    <Link
                      to="/app/profile"
                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-[#F97316] transition-colors"
                      onClick={() => setUserMenuOpen(false)}
                    >
                      <Settings size={16} className="mr-3" />
                      Account Settings
                    </Link>
                    <Link
                      to="/help"
                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-[#F97316] transition-colors"
                    >
                      <HelpCircle size={16} className="mr-3" />
                      Help & Support
                    </Link>
                    <hr className="my-2 border-gray-200" />
                    <button className="w-full flex items-center px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors">
                      <LogOut size={16} className="mr-3" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Page content */}
        <main className="flex-1 p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

export default DashboardLayout
