import { Pill, TrendingUp, Calendar, Clock, CheckCircle } from "lucide-react"

const StatCard = ({ title, value, icon: Icon, color = "blue", trend }) => (
  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-gray-600">{title}</p>
        <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
        {trend && (
          <p className="text-sm text-green-600 mt-1">
            <TrendingUp size={16} className="inline mr-1" />
            {trend}
          </p>
        )}
      </div>
      <div className={`p-3 rounded-lg bg-${color}-100`}>
        <Icon size={24} className={`text-${color}-600`} />
      </div>
    </div>
  </div>
)

const MedicationCard = ({ name, dosage, nextDose, status }) => (
  <div className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow">
    <div className="flex items-center justify-between mb-3">
      <h3 className="font-semibold text-gray-900">{name}</h3>
      <span
        className={`px-2 py-1 rounded-full text-xs font-medium ${
          status === "taken"
            ? "bg-green-100 text-green-800"
            : status === "due"
              ? "bg-yellow-100 text-yellow-800"
              : "bg-gray-100 text-gray-800"
        }`}
      >
        {status}
      </span>
    </div>
    <p className="text-sm text-gray-600 mb-2">{dosage}</p>
    <div className="flex items-center text-sm text-gray-500">
      <Clock size={16} className="mr-1" />
      Next: {nextDose}
    </div>
  </div>
)

const Dashboard = () => {
  const todaysMedications = [
    { name: "Lisinopril", dosage: "10mg", nextDose: "2:00 PM", status: "due" },
    { name: "Metformin", dosage: "500mg", nextDose: "6:00 PM", status: "upcoming" },
    { name: "Vitamin D", dosage: "1000 IU", nextDose: "Tomorrow 8:00 AM", status: "taken" },
    { name: "Aspirin", dosage: "81mg", nextDose: "Tomorrow 8:00 AM", status: "taken" },
  ]

  const upcomingReminders = [
    { medication: "Lisinopril", time: "2:00 PM", type: "WhatsApp" },
    { medication: "Metformin", time: "6:00 PM", type: "Email" },
    { medication: "Blood Pressure Check", time: "7:00 PM", type: "WhatsApp" },
  ]

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-[#F97316] to-[#FB923C] rounded-xl p-4 sm:p-6 text-white">
        <h1 className="text-xl sm:text-2xl font-bold mb-2">Good afternoon, John! 👋</h1>
        <p className="text-sm sm:text-base text-orange-100">
          You have 2 medications due today. Keep up the great work!
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <StatCard title="Today's Medications" value="4" icon={Pill} color="orange" />
        <StatCard title="Adherence Rate" value="94%" icon={CheckCircle} color="green" trend="+2% this week" />
        <StatCard title="Current Streak" value="12 days" icon={TrendingUp} color="blue" />
        <StatCard title="Next Refill" value="5 days" icon={Calendar} color="purple" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 sm:gap-6">
        {/* Today's Medications */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Today's Medications</h2>
          </div>
          <div className="p-6 space-y-4">
            {todaysMedications.map((med, index) => (
              <MedicationCard key={index} {...med} />
            ))}
          </div>
        </div>

        {/* Upcoming Reminders */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Upcoming Reminders</h2>
          </div>
          <div className="p-6 space-y-4">
            {upcomingReminders.map((reminder, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{reminder.medication}</p>
                  <p className="text-sm text-gray-600">{reminder.time}</p>
                </div>
                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">
                  {reminder.type}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
