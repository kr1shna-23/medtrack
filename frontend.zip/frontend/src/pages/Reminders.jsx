"use client"

import { useState } from "react"
import { Bell, Plus, Clock, Mail, MessageSquare, Edit, Trash2, X, Save } from "lucide-react"

const ReminderModal = ({ isOpen, onClose, reminder = null, onSave }) => {
  const [formData, setFormData] = useState({
    medication: reminder?.medication || "",
    dosage: reminder?.dosage || "",
    time: reminder?.time || "",
    frequency: reminder?.frequency || "Daily",
    type: reminder?.type || "whatsapp",
    active: reminder?.active ?? true,
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    onSave(formData)
    onClose()
  }

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    })
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50 transition-opacity" onClick={onClose}></div>

        <div className="relative bg-white rounded-xl shadow-xl max-w-md w-full mx-4 sm:mx-0">
          <div className="flex items-center justify-between p-4 sm:p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">{reminder ? "Edit Reminder" : "Add Reminder"}</h3>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
              <X size={20} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Medication</label>
              <input
                type="text"
                name="medication"
                value={formData.medication}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                placeholder="e.g., Lisinopril"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Dosage</label>
                <input
                  type="text"
                  name="dosage"
                  value={formData.dosage}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                  placeholder="e.g., 10mg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Time</label>
                <input
                  type="time"
                  name="time"
                  value={formData.time}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Frequency</label>
                <select
                  name="frequency"
                  value={formData.frequency}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                >
                  <option value="Daily">Daily</option>
                  <option value="Twice daily">Twice daily</option>
                  <option value="Three times daily">Three times daily</option>
                  <option value="Weekly">Weekly</option>
                  <option value="As needed">As needed</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Method</label>
                <select
                  name="type"
                  value={formData.type}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                >
                  <option value="whatsapp">WhatsApp</option>
                  <option value="email">Email</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <h4 className="font-medium text-gray-900">Active Reminder</h4>
                <p className="text-sm text-gray-600">Enable this reminder</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  name="active"
                  checked={formData.active}
                  onChange={handleChange}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[#F97316]/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#F97316]"></div>
              </label>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 px-4 py-2 bg-[#F97316] text-white rounded-lg hover:bg-[#F97316]/90 transition-colors flex items-center justify-center"
              >
                <Save size={16} className="mr-2" />
                {reminder ? "Update" : "Add"} Reminder
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

const ReminderCard = ({ reminder, onEdit, onDelete }) => {
  const getTypeIcon = (type) => {
    switch (type) {
      case "email":
        return <Mail size={16} className="text-blue-600" />
      case "whatsapp":
        return <MessageSquare size={16} className="text-green-600" />
      default:
        return <Bell size={16} className="text-gray-600" />
    }
  }

  const getTypeColor = (type) => {
    switch (type) {
      case "email":
        return "bg-blue-100 text-blue-800"
      case "whatsapp":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 sm:p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1 min-w-0">
          <h3 className="text-base sm:text-lg font-semibold text-gray-900 truncate">{reminder.medication}</h3>
          <p className="text-sm text-gray-600">{reminder.dosage}</p>
        </div>
        <div className="flex space-x-1 sm:space-x-2 ml-2">
          <button
            onClick={() => onEdit(reminder)}
            className="p-2 text-gray-500 hover:text-[#F97316] hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Edit size={16} />
          </button>
          <button
            onClick={() => onDelete(reminder.id)}
            className="p-2 text-gray-500 hover:text-red-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      <div className="space-y-2 sm:space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Time:</span>
          <span className="text-sm font-medium text-gray-900 flex items-center">
            <Clock size={14} className="mr-1" />
            {reminder.time}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Frequency:</span>
          <span className="text-sm font-medium text-gray-900">{reminder.frequency}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Method:</span>
          <span
            className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(reminder.type)}`}
          >
            {getTypeIcon(reminder.type)}
            <span className="ml-1 capitalize">{reminder.type}</span>
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Status:</span>
          <span
            className={`px-2 py-1 rounded-full text-xs font-medium ${
              reminder.active ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
            }`}
          >
            {reminder.active ? "Active" : "Inactive"}
          </span>
        </div>
      </div>
    </div>
  )
}

const Reminders = () => {
  const [activeTab, setActiveTab] = useState("all")
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingReminder, setEditingReminder] = useState(null)

  const reminders = [
    {
      id: 1,
      medication: "Lisinopril",
      dosage: "10mg",
      time: "2:00 PM",
      frequency: "Daily",
      type: "whatsapp",
      active: true,
    },
    {
      id: 2,
      medication: "Metformin",
      dosage: "500mg",
      time: "8:00 AM, 6:00 PM",
      frequency: "Twice daily",
      type: "email",
      active: true,
    },
    {
      id: 3,
      medication: "Vitamin D3",
      dosage: "1000 IU",
      time: "8:00 AM",
      frequency: "Daily",
      type: "whatsapp",
      active: true,
    },
    {
      id: 4,
      medication: "Aspirin",
      dosage: "81mg",
      time: "8:00 AM",
      frequency: "Daily",
      type: "email",
      active: false,
    },
  ]

  const filteredReminders = reminders.filter((reminder) => {
    if (activeTab === "all") return true
    if (activeTab === "active") return reminder.active
    if (activeTab === "inactive") return !reminder.active
    return reminder.type === activeTab
  })

  const handleEdit = (reminder) => {
    setEditingReminder(reminder)
    setIsModalOpen(true)
  }

  const handleDelete = (id) => {
    console.log("Delete reminder:", id)
    // Handle delete logic
  }

  const handleAddNew = () => {
    setEditingReminder(null)
    setIsModalOpen(true)
  }

  const handleSave = (formData) => {
    console.log("Save reminder:", formData)
    // Handle save logic
  }

  const tabs = [
    { id: "all", label: "All Reminders", count: reminders.length },
    { id: "active", label: "Active", count: reminders.filter((r) => r.active).length },
    { id: "whatsapp", label: "WhatsApp", count: reminders.filter((r) => r.type === "whatsapp").length },
    { id: "email", label: "Email", count: reminders.filter((r) => r.type === "email").length },
  ]

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Reminders</h1>
          <p className="text-sm sm:text-base text-gray-600 mt-1">Manage your medication reminders and notifications</p>
        </div>
        <button
          onClick={handleAddNew}
          className="inline-flex items-center justify-center px-4 py-2 bg-[#F97316] text-white rounded-lg hover:bg-[#F97316]/90 transition-colors text-sm sm:text-base"
        >
          <Plus size={18} className="mr-2" />
          Add Reminder
        </button>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200">
        <div className="border-b border-gray-200 overflow-x-auto">
          <nav className="flex space-x-4 sm:space-x-8 px-4 sm:px-6" aria-label="Tabs">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                  activeTab === tab.id
                    ? "border-[#F97316] text-[#F97316]"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                {tab.label}
                <span className="ml-2 bg-gray-100 text-gray-900 py-0.5 px-2.5 rounded-full text-xs">{tab.count}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Reminders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6">
        {filteredReminders.map((reminder) => (
          <ReminderCard key={reminder.id} reminder={reminder} onEdit={handleEdit} onDelete={handleDelete} />
        ))}
      </div>

      {filteredReminders.length === 0 && (
        <div className="text-center py-8 sm:py-12">
          <div className="w-20 h-20 sm:w-24 sm:h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
            <Bell size={24} className="sm:w-8 sm:h-8 text-gray-400" />
          </div>
          <h3 className="text-base sm:text-lg font-medium text-gray-900 mb-2">No reminders found</h3>
          <p className="text-sm sm:text-base text-gray-600">Create your first reminder to get started</p>
        </div>
      )}

      {/* Quick Setup */}
      <div className="bg-gradient-to-r from-[#F97316]/10 to-[#FB923C]/10 rounded-xl p-4 sm:p-6 border border-[#F97316]/20">
        <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-2">Quick Reminder Setup</h3>
        <p className="text-sm sm:text-base text-gray-600 mb-4">Set up reminders for all your medications at once</p>
        <div className="flex flex-col sm:flex-row gap-3">
          <button className="inline-flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm sm:text-base">
            <MessageSquare size={16} className="mr-2" />
            Enable WhatsApp
          </button>
          <button className="inline-flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm sm:text-base">
            <Mail size={16} className="mr-2" />
            Enable Email
          </button>
        </div>
      </div>

      {/* Modal */}
      <ReminderModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        reminder={editingReminder}
        onSave={handleSave}
      />
    </div>
  )
}

export default Reminders
