"use client"

import { useState } from "react"
import { Plus, Search, Filter, Edit, Trash2, Clock, Calendar, X, Save } from "lucide-react"

const MedicationModal = ({ isOpen, onClose, medication = null, onSave }) => {
  const [formData, setFormData] = useState({
    name: medication?.name || "",
    type: medication?.type || "",
    dosage: medication?.dosage || "",
    frequency: medication?.frequency || "",
    time: medication?.time || "",
    refillDate: medication?.refillDate || "",
    refillReminder: medication?.refillReminder || 7,
    notes: medication?.notes || "",
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    onSave(formData)
    onClose()
  }

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50 transition-opacity" onClick={onClose}></div>

        <div className="relative bg-white rounded-xl shadow-xl max-w-lg w-full mx-4 sm:mx-0 max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-between p-4 sm:p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">{medication ? "Edit Medication" : "Add Medication"}</h3>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
              <X size={20} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Medication Name</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                placeholder="e.g., Lisinopril"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Type</label>
                <select
                  name="type"
                  value={formData.type}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                >
                  <option value="">Select type</option>
                  <option value="Blood Pressure">Blood Pressure</option>
                  <option value="Diabetes">Diabetes</option>
                  <option value="Heart Health">Heart Health</option>
                  <option value="Supplement">Supplement</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Dosage</label>
                <input
                  type="text"
                  name="dosage"
                  value={formData.dosage}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                  placeholder="e.g., 10mg"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Frequency</label>
                <select
                  name="frequency"
                  value={formData.frequency}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                >
                  <option value="">Select frequency</option>
                  <option value="Once daily">Once daily</option>
                  <option value="Twice daily">Twice daily</option>
                  <option value="Three times daily">Three times daily</option>
                  <option value="As needed">As needed</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Time</label>
                <input
                  type="time"
                  name="time"
                  value={formData.time}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                />
              </div>
            </div>

            {/* Refill Information */}
            <div className="border-t border-gray-200 pt-4">
              <h4 className="text-sm font-medium text-gray-900 mb-3">Refill Information</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Refill Date</label>
                  <input
                    type="date"
                    name="refillDate"
                    value={formData.refillDate}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Remind me (days before)</label>
                  <select
                    name="refillReminder"
                    value={formData.refillReminder}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                  >
                    <option value="3">3 days before</option>
                    <option value="5">5 days before</option>
                    <option value="7">7 days before</option>
                    <option value="10">10 days before</option>
                    <option value="14">14 days before</option>
                  </select>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Notes (Optional)</label>
              <textarea
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none"
                placeholder="Any special instructions..."
              />
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 px-4 py-2 bg-[#F97316] text-white rounded-lg hover:bg-[#F97316]/90 transition-colors flex items-center justify-center"
              >
                <Save size={16} className="mr-2" />
                {medication ? "Update" : "Add"} Medication
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

const MedicationCard = ({ medication, onEdit, onDelete }) => (
  <div className="bg-white rounded-lg border border-gray-200 p-4 sm:p-6 hover:shadow-md transition-shadow">
    <div className="flex items-start justify-between mb-4">
      <div className="flex-1 min-w-0">
        <h3 className="text-base sm:text-lg font-semibold text-gray-900 truncate">{medication.name}</h3>
        <p className="text-sm text-gray-600">{medication.type}</p>
      </div>
      <div className="flex space-x-1 sm:space-x-2 ml-2">
        <button
          onClick={() => onEdit(medication)}
          className="p-2 text-gray-500 hover:text-[#F97316] hover:bg-gray-100 rounded-lg transition-colors"
        >
          <Edit size={16} />
        </button>
        <button
          onClick={() => onDelete(medication.id)}
          className="p-2 text-gray-500 hover:text-red-600 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <Trash2 size={16} />
        </button>
      </div>
    </div>

    <div className="space-y-2 sm:space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">Dosage:</span>
        <span className="text-sm font-medium text-gray-900">{medication.dosage}</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">Frequency:</span>
        <span className="text-sm font-medium text-gray-900">{medication.frequency}</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">Next Dose:</span>
        <span className="text-sm font-medium text-gray-900 flex items-center">
          <Clock size={14} className="mr-1" />
          {medication.nextDose}
        </span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">Refill Date:</span>
        <span className="text-sm font-medium text-gray-900 flex items-center">
          <Calendar size={14} className="mr-1" />
          {medication.refillDate}
        </span>
      </div>
    </div>

    {medication.notes && (
      <div className="mt-4 p-3 bg-gray-50 rounded-lg">
        <p className="text-sm text-gray-600">{medication.notes}</p>
      </div>
    )}
  </div>
)

const Medications = () => {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingMedication, setEditingMedication] = useState(null)

  const medications = [
    {
      id: 1,
      name: "Lisinopril",
      type: "Blood Pressure",
      dosage: "10mg",
      frequency: "Once daily",
      nextDose: "Today 2:00 PM",
      refillDate: "Jan 15, 2024",
      notes: "Take with food to reduce stomach upset",
    },
    {
      id: 2,
      name: "Metformin",
      type: "Diabetes",
      dosage: "500mg",
      frequency: "Twice daily",
      nextDose: "Today 6:00 PM",
      refillDate: "Jan 20, 2024",
      notes: "Monitor blood sugar levels",
    },
    {
      id: 3,
      name: "Vitamin D3",
      type: "Supplement",
      dosage: "1000 IU",
      frequency: "Once daily",
      nextDose: "Tomorrow 8:00 AM",
      refillDate: "Feb 1, 2024",
      notes: "",
    },
    {
      id: 4,
      name: "Aspirin",
      type: "Heart Health",
      dosage: "81mg",
      frequency: "Once daily",
      nextDose: "Tomorrow 8:00 AM",
      refillDate: "Jan 25, 2024",
      notes: "Low-dose for heart protection",
    },
  ]

  const filteredMedications = medications.filter((med) => {
    const matchesSearch =
      med.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      med.type.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter = filterType === "all" || med.type.toLowerCase().includes(filterType.toLowerCase())
    return matchesSearch && matchesFilter
  })

  const handleEdit = (medication) => {
    setEditingMedication(medication)
    setIsModalOpen(true)
  }

  const handleDelete = (id) => {
    console.log("Delete medication:", id)
    // Handle delete logic
  }

  const handleAddNew = () => {
    setEditingMedication(null)
    setIsModalOpen(true)
  }

  const handleSave = (formData) => {
    console.log("Save medication:", formData)
    // Handle save logic
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Medications</h1>
          <p className="text-sm sm:text-base text-gray-600 mt-1">Manage your medication schedule and information</p>
        </div>
        <button
          onClick={handleAddNew}
          className="inline-flex items-center justify-center px-4 py-2 bg-[#F97316] text-white rounded-lg hover:bg-[#F97316]/90 transition-colors text-sm sm:text-base"
        >
          <Plus size={18} className="mr-2" />
          Add Medication
        </button>
      </div>

      {/* Search and Filter */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search medications..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none text-sm sm:text-base"
            />
          </div>
          <div className="relative">
            <Filter size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#F97316] focus:border-transparent outline-none bg-white text-sm sm:text-base min-w-[140px]"
            >
              <option value="all">All Types</option>
              <option value="blood pressure">Blood Pressure</option>
              <option value="diabetes">Diabetes</option>
              <option value="supplement">Supplement</option>
              <option value="heart">Heart Health</option>
            </select>
          </div>
        </div>
      </div>

      {/* Medications Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-6">
        {filteredMedications.map((medication) => (
          <MedicationCard key={medication.id} medication={medication} onEdit={handleEdit} onDelete={handleDelete} />
        ))}
      </div>

      {filteredMedications.length === 0 && (
        <div className="text-center py-8 sm:py-12">
          <div className="w-20 h-20 sm:w-24 sm:h-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
            <Search size={24} className="sm:w-8 sm:h-8 text-gray-400" />
          </div>
          <h3 className="text-base sm:text-lg font-medium text-gray-900 mb-2">No medications found</h3>
          <p className="text-sm sm:text-base text-gray-600">Try adjusting your search or filter criteria</p>
        </div>
      )}

      {/* Modal */}
      <MedicationModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        medication={editingMedication}
        onSave={handleSave}
      />
    </div>
  )
}

export default Medications
